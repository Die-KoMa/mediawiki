<?php

namespace MediaWiki\Extension\UserMerge;

use MediaWiki\Logging\LogFormatter;

class UserMergeLogFormatter extends LogFormatter {

	/** @var int[] */
	private static $mapLegacy = [
		'oldName' => 0,
		'oldId' => 1,
		'newName' => 2,
		'newId' => 3,
	];

	protected function getMessageKey(): string {
		if ( $this->entry->getSubtype() === 'deleteuser' ) {
			return 'logentry-usermerge-deleteuser';
		} else {
			return 'logentry-usermerge-mergeuser';
		}
	}

	/**
	 * @param string $param
	 * @return mixed
	 */
	private function getParameter( string $param ) {
		$parameters = $this->entry->getParameters();
		if ( $this->entry->isLegacy() ) {
			$param = self::$mapLegacy[$param];
		}
		return $parameters[$param];
	}

	protected function extractParameters(): array {
		$params = [];
		// 0-2 are set in LogFormatter::getMessageParameters()
		$params[3] = $this->getParameter( 'oldName' );
		$params[4] = $this->getParameter( 'oldId' );
		if ( $this->entry->getSubtype() !== 'deleteuser' ) {
			$params[5] = $this->formatParameterValue(
				'user-link', $this->getParameter( 'newName' ) );
			$params[6] = $this->getParameter( 'newId' );
			$params[7] = $this->formatParameterValue(
				'user', $this->getParameter( 'newName' ) );
		}
		return $params;
	}

}
