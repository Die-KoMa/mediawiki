<?php
/**
 * Magic word internationalisation for Description2 extension
 *
 * @file
 * @ingroup Extensions
 */

$magicWords = [];

/** English
 * @author Daniel Friesen
 */
$magicWords['en'] = [
	'description2' => [ 0, 'description2' ],
];
